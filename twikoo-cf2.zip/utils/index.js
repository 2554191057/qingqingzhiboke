const { URL } = require('url')
const {
  getAxios,
  getFormData,
  getBowser,
  getIpToRegion,
  getMd5,
  getSha256
} = require('./lib')
const axios = getAxios()
const FormData = getFormData()
const bowser = getBowser()
const md5 = getMd5()
const sha256 = getSha256()
const { RES_CODE } = require('./constants')
const logger = require('./logger')

let ipRegionSearcher

// IP 属地查询
function getIpRegionSearcher () {
  if (!ipRegionSearcher) {
    const ipToRegion = getIpToRegion()
    ipRegionSearcher = ipToRegion.create() // 初始化 IP 属地
  }
  return ipRegionSearcher
}

const fn = {
  // 获取 Twikoo 云函数版本
  getFuncVersion (VERSION) {
    return {
      code: RES_CODE.SUCCESS,
      version: VERSION
    }
  },
  // 同时查询 /path 和 /path/ 的评论
  getUrlQuery (url) {
    const variantUrl = url[url.length - 1] === '/' ? url.substring(0, url.length - 1) : `${url}/`
    return [url, variantUrl]
  },
  getUrlsQuery (urls) {
    const query = []
    for (const url of urls) {
      if (url) query.push(...fn.getUrlQuery(url))
    }
    return query
  },
  // 筛除隐私字段，拼接回复列表
  parseComment (comments, uid, config) {
    const result = []
    for (const comment of comments) {
      if (!comment.rid) {
        const replies = comments
          .filter((item) => item.rid === comment._id.toString())
          .map((item) => fn.toCommentDto(item, uid, [], comments, config))
          .sort((a, b) => a.created - b.created)
        result.push(fn.toCommentDto(comment, uid, replies, [], config))
      }
    }
    return result
  },
  // 将评论记录转换为前端需要的格式
  toCommentDto (comment, uid, replies = [], comments = [], config) {
    let displayOs = ''
    let displayBrowser = ''
    if (config.SHOW_UA !== 'false') {
      try {
        const ua = bowser.getParser(comment.ua)
        const os = fn.fixOS(ua)
        displayOs = [os.name, os.versionName ? os.versionName : os.version].join(' ')
        displayBrowser = [ua.getBrowserName(), ua.getBrowserVersion()].join(' ')
      } catch (e) {
        logger.warn('bowser 错误：', e)
      }
    }
    const showRegion = !!config.SHOW_REGION && config.SHOW_REGION !== 'false'
    const ups = comment.ups || []
    const downs = comment.downs || []
    return {
      id: comment._id.toString(),
      nick: comment.nick,
      avatar: comment.avatar,
      mailMd5: fn.getMailMd5(comment),
      link: comment.link,
      comment: comment.comment,
      os: displayOs,
      browser: displayBrowser,
      ipRegion: showRegion ? fn.getIpRegion({ ip: comment.ip }) : '',
      master: comment.master,
      like: comment.like ? comment.like.length : 0,
      ups: ups.length,
      downs: downs.length,
      liked: ups.includes(uid),
      disliked: downs.includes(uid),
      replies,
      rid: comment.rid,
      pid: comment.pid,
      ruser: fn.ruser(comment.pid, comments),
      top: comment.top,
      isSpam: comment.isSpam,
      isOwner: Boolean(uid && comment.uid === uid),
      created: comment.created,
      updated: comment.updated
    }
  },
  fixOS (ua) {
    const os = ua.getOS()
    if (!os.versionName) {
      // fix version name of Win 11 & macOS ^11 & Android ^10
      if (os.name === 'Windows' && os.version === 'NT 11.0') {
        os.versionName = '11'
      } else if (os.name === 'macOS') {
        const majorPlatformVersion = os.version.split('.')[0]
        os.versionName = {
          11: 'Big Sur',
          12: 'Monterey',
          13: 'Ventura',
          14: 'Sonoma',
          15: 'Sequoia',
          16: 'Tahoe'
        }[majorPlatformVersion]
      } else if (os.name === 'Android') {
        const majorPlatformVersion = os.version.split('.')[0]
        os.versionName = {
          10: 'Quince Tart',
          11: 'Red Velvet Cake',
          12: 'Snow Cone',
          13: 'Tiramisu',
          14: 'Upside Down Cake',
          15: 'Vanilla Ice Cream',
          16: 'Baklava'
        }[majorPlatformVersion]
      } else if (ua.test(/harmony/i)) {
        os.name = 'Harmony'
        os.version = fn.getFirstMatch(/harmony[\s/-](\d+(\.\d+)*)/i, ua.getUA())
        os.versionName = ''
      }
    }
    return os
  },
  /**
   * Get first matched item for a string
   * @param {RegExp} regexp
   * @param {String} ua
   * @return {Array|{index: number, input: string}|*|boolean|string}
   */
  getFirstMatch (regexp, ua) {
    const match = ua.match(regexp)
    return (match && match.length > 0 && match[1]) || ''
  },
  // 获取回复人昵称 / Get replied user nick name
  ruser (pid, comments = []) {
    const comment = comments.find((item) => item._id === pid)
    return comment ? comment.nick : null
  },
  /**
   * 获取 IP 属地
   * @param detail true 返回省市运营商，false 只返回省
   * @returns {String}
   */
  getIpRegion ({ ip, detail = false }) {
    if (!ip) return ''
    try {
      // 将 IPv6 格式的 IPv4 地址转换为 IPv4 格式
      ip = ip.replace(/^::ffff:/, '')
      // Zeabur 返回的地址带端口号，去掉端口号。TODO: 不知道该怎么去掉 IPv6 地址后面的端口号
      ip = ip.replace(/:[0-9]*$/, '')
      const { region } = getIpRegionSearcher().binarySearchSync(ip)
      const [country,, province, city, isp] = region.split('|')
      // 有省显示省，没有省显示国家
      const area = province.trim() && province !== '0' ? province : country
      if (detail) {
        return area === city ? [city, isp].join(' ') : [area, city, isp].join(' ')
      } else {
        return area.replace(/(省|市)$/, '')
      }
    } catch (e) {
      logger.warn('IP 属地查询失败：', e.message, ip)
      return ''
    }
  },
  parseCommentForAdmin (comments) {
    for (const comment of comments) {
      comment.ipRegion = fn.getIpRegion({ ip: comment.ip, detail: true })
    }
    return comments
  },
  getRelativeUrl (url) {
    try {
      return (new URL(url)).pathname
    } catch (e) {
      // 如果 url 已经是一个相对地址了，会报 ERR_INVALID_URL，返回原始 url 就行
      return url
    }
  },
  normalizeMail (mail) {
    return String(mail).trim().toLowerCase()
  },
  equalsMail (mail1, mail2) {
    if (!mail1 || !mail2) return false
    return fn.normalizeMail(mail1) === fn.normalizeMail(mail2)
  },
  getMailMd5 (comment) {
    if (comment.mailMd5) {
      return comment.mailMd5
    }
    if (comment.mail) {
      return md5(fn.normalizeMail(comment.mail))
    }
    return md5(comment.nick)
  },
  getMailSha256 (comment) {
    if (comment.mail) {
      return sha256(fn.normalizeMail(comment.mail))
    }
    return sha256(comment.nick)
  },
  getAvatar (comment, config) {
    if (comment.avatar) {
      return comment.avatar
    } else {
      const gravatarCdn = config.GRAVATAR_CDN || 'weavatar.com'
      let defaultGravatar = `initials&name=${comment.nick}`
      if (config.DEFAULT_GRAVATAR) {
        defaultGravatar = config.DEFAULT_GRAVATAR
      }
      const mailHash = gravatarCdn === 'cravatar.cn' ? fn.getMailMd5(comment) : fn.getMailSha256(comment) // Cravatar 不支持 sha256
      return `https://${gravatarCdn}/avatar/${mailHash}?d=${defaultGravatar}`
    }
  },
  isUrl (s) {
    return /^http(s)?:\/\//.test(s)
  },
  isValidEmail (mail) {
    if (!mail || typeof mail !== 'string') return false
    const trimmed = mail.trim()
    if (!trimmed) return false
    // Reject emails with characters that could trigger nodemailer addressparser group parsing (CVE-2025-14874)
    if (trimmed.indexOf(':') !== -1) return false
    if (trimmed.indexOf(' ') !== -1) return false
    if (trimmed.indexOf(';') !== -1) return false
    // Basic email format validation
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)
  },
  isQQ (mail) {
    return /^[1-9][0-9]{4,10}$/.test(mail) ||
      /^[1-9][0-9]{4,10}@qq.com$/i.test(mail)
  },
  addQQMailSuffix (mail) {
    if (/^[1-9][0-9]{4,10}$/.test(mail)) return `${mail}@qq.com`
    else return mail
  },
  async getQQAvatar (qq) {
    try {
      const qqNum = qq.replace(/@qq.com/ig, '')
      // TODO: 这个接口已经失效了，暂时找不到新的接口
      const result = await axios.get(`https://aq.qq.com/cn2/get_img/get_face?img_type=3&uin=${qqNum}`)
      return result.data?.url || null
    } catch (e) {
      logger.warn('获取 QQ 头像失败：', e)
    }
  },
  async getQQNick (qq, qqApiKey) {
    try {
      const qqNum = qq.replace(/@qq.com/ig, '')
      const headers = {}
      if (qqApiKey) {
        headers.Authorization = `Bearer ${qqApiKey}`
      }
      const result = await axios.get(`https://v1.tqq.me/v1/qqname?qq=${qqNum}`, { headers })
      if (result.data?.code === 200 && result.data?.data?.nick) {
        return result.data.data.nick
      }
      return null
    } catch (e) {
      logger.warn('获取 QQ 昵称失败：', e)
      return null
    }
  },
  // 判断是否存在管理员密码
  async getPasswordStatus (config, version) {
    return {
      code: RES_CODE.SUCCESS,
      status: !!config.ADMIN_PASS,
      credentials: !!config.CREDENTIALS,
      version
    }
  },
  // 预垃圾评论检测
  preCheckSpam ({ comment, nick, link, mail }, config) {
    // 长度限制
    let limitLength = parseInt(config.LIMIT_LENGTH)
    if (Number.isNaN(limitLength)) limitLength = 500
    if (limitLength && comment.length > limitLength) {
      throw new Error('评论内容过长')
    }
    if (config.BLOCKED_WORDS) {
      const commentLowerCase = comment.toLowerCase()
      const nickLowerCase = nick.toLowerCase()
      for (const blockedWord of config.BLOCKED_WORDS.split(',')) {
        const blockedWordLowerCase = blockedWord.trim().toLowerCase()
        if (commentLowerCase.indexOf(blockedWordLowerCase) !== -1 || nickLowerCase.indexOf(blockedWordLowerCase) !== -1) {
          throw new Error('包含屏蔽词')
        }
      }
    }
    if (config.AKISMET_KEY === 'MANUAL_REVIEW') {
      // 人工审核
      logger.info('已使用人工审核模式，评论审核后才会发表~')
      return true
    } else if (config.FORBIDDEN_WORDS) {
      // 违禁词检测
      const commentLowerCase = comment.toLowerCase()
      const nickLowerCase = nick.toLowerCase()
      const linkLowerCase = (link || '').toLowerCase()
      const mailLowerCase = (mail || '').toLowerCase()
      for (const forbiddenWord of config.FORBIDDEN_WORDS.replace(/,+$/, '').split(',')) {
        const forbiddenWordLowerCase = forbiddenWord.trim().toLowerCase()
        if (commentLowerCase.indexOf(forbiddenWordLowerCase) !== -1 || nickLowerCase.indexOf(forbiddenWordLowerCase) !== -1 || linkLowerCase.indexOf(forbiddenWordLowerCase) !== -1 || mailLowerCase.indexOf(forbiddenWordLowerCase) !== -1) {
          logger.warn('包含违禁词，直接标记为垃圾评论~')
          return true
        }
      }
    }
    return false
  },
  async checkTurnstileCaptcha ({ ip, turnstileToken, turnstileTokenSecretKey }) {
    try {
      const formData = new FormData()
      formData.append('secret', turnstileTokenSecretKey)
      formData.append('response', turnstileToken)
      formData.append('remoteip', ip)
      const { data } = await axios.post('https://challenges.cloudflare.com/turnstile/v0/siteverify', formData, {
        headers: formData.getHeaders()
      })
      logger.log('验证码检测结果', data)
      if (!data.success) throw new Error('验证码错误')
    } catch (e) {
      throw new Error('验证码检测失败: ' + e.message)
    }
  },
  async checkGeeTestCaptcha ({ geeTestCaptchaId, geeTestCaptchaKey, geeTestLotNumber, geeTestCaptchaOutput, geeTestPassToken, geeTestGenTime }) {
    try {
      logger.log('极验验证参数:', { geeTestCaptchaId, geeTestCaptchaKey: geeTestCaptchaKey ? '***' : undefined, geeTestLotNumber })
      const crypto = require('crypto')
      const signToken = crypto
        .createHmac('sha256', geeTestCaptchaKey)
        .update(geeTestLotNumber)
        .digest('hex')
      const params = new URLSearchParams()
      params.append('lot_number', geeTestLotNumber)
      params.append('captcha_output', geeTestCaptchaOutput)
      params.append('pass_token', geeTestPassToken)
      params.append('gen_time', geeTestGenTime)
      params.append('sign_token', signToken)
      logger.log('极验请求参数:', params.toString())
      const url = `https://gcaptcha4.geetest.com/validate?captcha_id=${geeTestCaptchaId}`
      const { data } = await axios.post(url, params.toString(), {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      })
      logger.log('极验验证码检测结果', JSON.stringify(data))
      if (data.result !== 'success') {
        logger.error('极验验证失败详情:', data)
        throw new Error(data.reason || data.msg || '验证码错误')
      }
    } catch (e) {
      throw new Error('极验验证码检测失败: ' + e.message)
    }
  },
  async checkCapCaptcha ({ capToken, capSecretKey, capApiEndpoint, cap }) {
    try {
      // 内嵌 Cap：直接 validateToken，无需外部 Standalone
      if (cap) {
        const { validateToken } = require('./cap')
        const ok = await validateToken(cap, capToken)
        if (!ok) throw new Error('验证码错误')
        return
      }
      // 外部 Cap Standalone：HTTP siteverify
      const endpoint = capApiEndpoint.replace(/\/$/, '')
      const url = `${endpoint}/siteverify`
      logger.log('Cap验证码验证URL:', url)
      logger.log('Cap验证码验证参数:', { secret: capSecretKey ? '***' : undefined, response: capToken.substring(0, 20) + '...' })
      const { data } = await axios.post(url, {
        secret: capSecretKey,
        response: capToken
      }, {
        headers: { 'Content-Type': 'application/json' }
      })
      logger.log('Cap验证码检测结果', data)
      if (!data.success) throw new Error(data.error || '验证码错误')
    } catch (e) {
      throw new Error('Cap验证码检测失败: ' + e.message)
    }
  },
  async getConfig ({ config, VERSION, isAdmin }) {
    // 构建对外配置，避免在启用某一验证码供应商时泄露另一个供应商的 key
    const baseConfig = {
      VERSION,
      IS_ADMIN: isAdmin,
      SITE_NAME: config.SITE_NAME,
      SITE_URL: config.SITE_URL,
      MASTER_TAG: config.MASTER_TAG,
      COMMENT_BG_IMG: config.COMMENT_BG_IMG,
      GRAVATAR_CDN: config.GRAVATAR_CDN,
      DEFAULT_GRAVATAR: config.DEFAULT_GRAVATAR,
      SHOW_IMAGE: config.SHOW_IMAGE || 'true',
      IMAGE_CDN: config.IMAGE_CDN,
      LIGHTBOX: config.LIGHTBOX || 'false',
      SHOW_EMOTION: config.SHOW_EMOTION || 'true',
      EMOTION_CDN: config.EMOTION_CDN,
      COMMENT_PLACEHOLDER: config.COMMENT_PLACEHOLDER,
      SHOW_ORDER: config.SHOW_ORDER || 'true',
      SHOW_DISLIKE: config.SHOW_DISLIKE || 'true',
      DISPLAYED_FIELDS: config.DISPLAYED_FIELDS,
      REQUIRED_FIELDS: config.REQUIRED_FIELDS,
      HIDE_ADMIN_CRYPT: config.HIDE_ADMIN_CRYPT,
      HIGHLIGHT: config.HIGHLIGHT || 'true',
      HIGHLIGHT_THEME: config.HIGHLIGHT_THEME,
      HIGHLIGHT_PLUGIN: config.HIGHLIGHT_PLUGIN,
      LIMIT_LENGTH: config.LIMIT_LENGTH,
      CAPTCHA_PROVIDER: config.CAPTCHA_PROVIDER
    }

    // 仅在明确指定使用 Turnstile 时下发 Turnstile 的 site key
    if (config.CAPTCHA_PROVIDER === 'Turnstile') {
      baseConfig.TURNSTILE_SITE_KEY = config.TURNSTILE_SITE_KEY
    }

    // 仅在明确指定使用 Geetest 时下发 Geetest 的 id
    if (config.CAPTCHA_PROVIDER === 'Geetest') {
      baseConfig.GEETEST_CAPTCHA_ID = config.GEETEST_CAPTCHA_ID
    }

    // Cap：有外部 endpoint 则下发；否则标记 builtin，前端走 twikoo 事件代理
    if (config.CAPTCHA_PROVIDER === 'Cap') {
      if (config.CAP_API_ENDPOINT) {
        baseConfig.CAP_API_ENDPOINT = config.CAP_API_ENDPOINT
      } else {
        baseConfig.CAP_BUILTIN = true
      }
    }

    return {
      code: RES_CODE.SUCCESS,
      config: baseConfig
    }
  },
  async getConfigForAdmin ({ config, isAdmin }) {
    if (isAdmin) {
      delete config.CREDENTIALS
      return {
        code: RES_CODE.SUCCESS,
        config
      }
    } else {
      return {
        code: RES_CODE.NEED_LOGIN,
        message: '请先登录'
      }
    }
  },
  // 请求参数校验
  validate (event = {}, requiredParams = []) {
    for (const requiredParam of requiredParams) {
      if (!event[requiredParam]) {
        throw new Error(`参数"${requiredParam}"不合法`)
      }
    }
  },
  // 客户端字段类型校验，防止 NoSQL 查询条件注入。
  // 以下字段会直接参与数据库查询或作为评论归属标识，
  // 如果传入对象，会被数据库解释为查询操作符（如 $ne、$gt），
  // 导致越权删除评论、绕过评论可见性限制等问题。
  // 允许字段缺省或为 null（兼容首次匿名请求），有值时必须是字符串。
  validateClientFields (event = {}) {
    const stringFields = ['accessToken', 'id', 'url', 'pid', 'rid']
    for (const field of stringFields) {
      const value = event[field]
      if (value !== undefined && value !== null && typeof value !== 'string') {
        throw new Error(`参数"${field}"必须是字符串`)
      }
    }
    if (event.urls !== undefined && event.urls !== null) {
      if (!Array.isArray(event.urls) || event.urls.some((url) => typeof url !== 'string')) {
        throw new Error('参数"urls"必须是字符串数组')
      }
    }
  },
  // 校验评论归属：确认评论存在且属于当前用户
  async checkCommentOwnership (id, uid, getComment) {
    fn.validate({ id }, ['id'])
    // 兜底校验：id 必须是字符串，防止查询操作符对象注入 _id 条件，
    // 绕过归属校验后批量删除评论
    if (typeof id !== 'string') {
      throw new Error('参数"id"必须是字符串')
    }
    const comment = await getComment(id)
    if (!comment) {
      throw new Error('评论不存在')
    }
    // 无 token 的请求不具备任何归属权，必须直接拒绝，
    // 防止 comment.uid 与 uid 同时为 undefined 时误判为本人
    if (!uid || comment.uid !== uid) {
      throw new Error('只能删除自己的评论')
    }
    return comment
  }
}

module.exports = fn
